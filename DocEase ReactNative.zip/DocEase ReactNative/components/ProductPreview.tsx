import { View, Text } from "react-native";
import React from "react";

const ProductPreview = () => {
    return (
        <View>
            <Text>ProductPreview</Text>
        </View>
    );
};

export default ProductPreview;

export default {
    primary: "#0a4d4a",
    grey: "#5E5D5E",
    dark: "#1A1A1A",
};